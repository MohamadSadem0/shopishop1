import React from "react";

const Settings = () => {
  return (
    <div className="p-8 bg-white">
      <h2 className="text-2xl font-semibold mb-4">Settings</h2>
      <p>This is the Super Admin settings page. (Static View)</p>
    </div>
  );
};

export default Settings;
