import React from "react";

import Login from "../Components/Login";

const LoginPage = () => {
  return (
    <div>
      <Login />
    </div>
  );
};

export default LoginPage;
