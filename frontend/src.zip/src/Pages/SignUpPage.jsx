import React from "react";
import Signup from "../Components/Signup";

const SignUpPage = () => {
  return (
    <div>
      <Signup />
    </div>
  );
};

export default SignUpPage;
